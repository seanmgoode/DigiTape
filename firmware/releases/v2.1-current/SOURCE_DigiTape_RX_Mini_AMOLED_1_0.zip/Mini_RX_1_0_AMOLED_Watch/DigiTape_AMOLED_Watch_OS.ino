#include <Arduino.h>
#include <Wire.h>
#include <lvgl.h>
#include <BLEDevice.h>
#include <BLEUtils.h>
#include <BLEScan.h>
#include <BLEClient.h>
#include <WiFi.h>
#include <WebServer.h>
#include <Preferences.h>
#include <time.h>
#include <sys/time.h>
#include <Adafruit_XCA9554.h>
#include "pin_config.h"
#include "XPowersLib.h"
#include "Arduino_GFX_Library.h"
#include "Arduino_DriveBus_Library.h"
#include "SensorPCF85063.hpp"
#include "lv_conf.h"
#include "HWCDC.h"

HWCDC USBSerial;
Adafruit_XCA9554 expander;
XPowersPMU power;
SensorPCF85063 rtc;
WebServer wifiServer(80);
Preferences wifiPrefs;

#define EXAMPLE_LVGL_TICK_PERIOD_MS 2

static lv_disp_draw_buf_t draw_buf;
static uint32_t screenWidth = LCD_WIDTH;
static uint32_t screenHeight = LCD_HEIGHT;

Arduino_DataBus *bus = new Arduino_ESP32QSPI(
  LCD_CS, LCD_SCLK, LCD_SDIO0, LCD_SDIO1, LCD_SDIO2, LCD_SDIO3);

Arduino_CO5300 *gfx = new Arduino_CO5300(
  bus, GFX_NOT_DEFINED, 0, LCD_WIDTH, LCD_HEIGHT, 16, 0, 0, 0);

std::shared_ptr<Arduino_IIC_DriveBus> IIC_Bus =
  std::make_shared<Arduino_HWIIC>(IIC_SDA, IIC_SCL, &Wire);

void Arduino_IIC_Touch_Interrupt(void);
LV_IMG_DECLARE(digitape_logo_boot);
LV_IMG_DECLARE(digitape_logo_flash);

std::unique_ptr<Arduino_IIC> CST816(new Arduino_CST816x(
  IIC_Bus, CST816T_DEVICE_ADDRESS, DRIVEBUS_DEFAULT_VALUE, TP_INT, Arduino_IIC_Touch_Interrupt));

static BLEUUID serviceUUID("6f8a1500-b5a3-4f4a-9d7f-1a2b3c4d5e6f");
static BLEUUID distanceUUID("6f8a1501-b5a3-4f4a-9d7f-1a2b3c4d5e6f");
static BLEUUID settingsUUID("6f8a1502-b5a3-4f4a-9d7f-1a2b3c4d5e6f");
static BLEUUID statusUUID("6f8a1503-b5a3-4f4a-9d7f-1a2b3c4d5e6f");

static const char *RX_NAME = "DigiTape-RX";
static const char *TX_NAME = "DigiTape-TX";
static const char *FIRMWARE_NAME = "Mini RX";
static const char *FIRMWARE_VERSION = "1.0";
static const char *DEFAULT_WIFI_SSID = "theinternet";
static const char *TIME_ZONE = "PST8PDT,M3.2.0,M11.1.0";
static const uint8_t BOTTOM_BUTTON_EXPANDER_PIN = 4;
static const uint8_t PMU_IRQ_EXPANDER_PIN = 5;
static const uint8_t BRIGHTNESS_LEVEL_VALUES[] = {70, 160, 255};

static BLEClient *client = nullptr;
static BLERemoteCharacteristic *distanceChar = nullptr;
static BLERemoteCharacteristic *settingsChar = nullptr;
static BLERemoteCharacteristic *statusChar = nullptr;
static BLEAdvertisedDevice *targetDevice = nullptr;

static String preferredRoute = "RX";
static const char *DISTANCE_PLACEHOLDER = "--' --\"";
static String distanceText = DISTANCE_PLACEHOLDER;
static String statusText = "Scanning";
static bool connected = false;
static uint32_t scanCount = 0;
static unsigned long lastScanMs = 0;
static unsigned long lastPacketMs = 0;
static unsigned long touchHoldUntilMs = 0;
static unsigned long touchTrackingUntilMs = 0;
static unsigned long navBlockUntilMs = 0;
static unsigned long touchSuppressUntilMs = 0;
static lv_point_t lastTouchPoint = {0, 0};
static lv_point_t swipeStartPoint = {0, 0};
static bool digitapeDirty = true;
static volatile bool backRequested = false;
static volatile bool settingsRequested = false;
static bool touchTracking = false;
static bool swipeTriggered = false;

enum AppScreen {
  SCREEN_HOME,
  SCREEN_TIME,
  SCREEN_DIGITAPE,
  SCREEN_SETTINGS,
  SCREEN_WIFI_SETUP,
  SCREEN_BRIGHTNESS,
  SCREEN_DIAGNOSTICS
};

static AppScreen currentScreen = SCREEN_HOME;
static lv_obj_t *root = nullptr;
static lv_obj_t *timeLabel = nullptr;
static lv_obj_t *dateLabel = nullptr;
static lv_obj_t *distanceLabel = nullptr;
static lv_obj_t *routeLabel = nullptr;
static lv_obj_t *routeButton = nullptr;
static lv_obj_t *routeButtonLabel = nullptr;
static lv_obj_t *statusLabel = nullptr;
static lv_obj_t *diagLabel = nullptr;
static lv_obj_t *brightnessSlider = nullptr;
static lv_obj_t *wifiStatusLabel = nullptr;
static lv_obj_t *batteryLabel = nullptr;
static uint8_t brightness = 160;
static uint8_t brightnessLevelIndex = 1;
static bool rtcReady = false;
static bool pmuReady = false;
static bool bleReady = false;
static bool wifiSetupActive = false;
static volatile bool wifiSetupRequested = false;
static bool bottomButtonWasPressed = false;
static bool bottomButtonIdleState = false;
static bool bottomButtonReady = false;
static bool powerKeyHeld = false;
static bool powerOffRequested = false;
static bool wifiConnectStarted = false;
static bool timeSyncStarted = false;
static bool timeSynced = false;
static bool systemTimeReady = false;
static unsigned long lastBottomButtonMs = 0;
static unsigned long powerKeyPressStartedMs = 0;
static unsigned long wifiConnectStartedMs = 0;
static unsigned long timeSyncStartedMs = 0;
static unsigned long lastTimeSyncAttemptMs = 0;
static String wifiSsid = DEFAULT_WIFI_SSID;
static String wifiStatus = "WiFi off";

void Arduino_IIC_Touch_Interrupt(void)
{
  CST816->IIC_Interrupt_Flag = true;
}

static void updateTimeLabels();
static void updateBatteryLabel();

static int buildMonthIndex(const char *month)
{
  static const char *months = "JanFebMarAprMayJunJulAugSepOctNovDec";
  const char *found = strstr(months, month);
  return found ? ((found - months) / 3) : 0;
}

static void seedClockFromBuildTime()
{
  setenv("TZ", TIME_ZONE, 1);
  tzset();

  struct tm buildTime = {};
  char month[4] = {};
  int day = 1;
  int year = 2026;
  int hour = 0;
  int minute = 0;
  int second = 0;
  sscanf(__DATE__, "%3s %d %d", month, &day, &year);
  sscanf(__TIME__, "%d:%d:%d", &hour, &minute, &second);

  buildTime.tm_year = year - 1900;
  buildTime.tm_mon = buildMonthIndex(month);
  buildTime.tm_mday = day;
  buildTime.tm_hour = hour;
  buildTime.tm_min = minute;
  buildTime.tm_sec = second;
  buildTime.tm_isdst = -1;

  time_t epoch = mktime(&buildTime);
  if (epoch > 1700000000) {
    struct timeval now = {epoch, 0};
    settimeofday(&now, NULL);
    systemTimeReady = true;
    if (rtcReady) {
      RTC_DateTime current = rtc.getDateTime();
      if (current.getYear() < 2024) {
        rtc.setDateTime(buildTime);
        USBSerial.println("[time] RTC seeded from build time");
      }
    }
  }
}

static const char *wantedName()
{
  return preferredRoute == "TX" ? TX_NAME : RX_NAME;
}

static void lvTick(void *)
{
  lv_tick_inc(EXAMPLE_LVGL_TICK_PERIOD_MS);
}

static void displayFlush(lv_disp_drv_t *disp, const lv_area_t *area, lv_color_t *color_p)
{
  uint32_t w = (area->x2 - area->x1 + 1);
  uint32_t h = (area->y2 - area->y1 + 1);
#if (LV_COLOR_16_SWAP != 0)
  gfx->draw16bitBeRGBBitmap(area->x1, area->y1, (uint16_t *)&color_p->full, w, h);
#else
  gfx->draw16bitRGBBitmap(area->x1, area->y1, (uint16_t *)&color_p->full, w, h);
#endif
  lv_disp_flush_ready(disp);
}

static bool normalizeTouchPoint(int32_t rawX, int32_t rawY, lv_point_t *point)
{
  if (rawX >= 0 && rawX < (int32_t)screenWidth && rawY >= 0 && rawY < (int32_t)screenHeight) {
    point->x = rawX;
    point->y = rawY;
    return true;
  }
  if (rawY >= 0 && rawY < (int32_t)screenWidth && rawX >= 0 && rawX < (int32_t)screenHeight) {
    point->x = rawY;
    point->y = rawX;
    return true;
  }
  return false;
}

static bool triggerNavigationSwipe(bool leftSwipe)
{
  if (swipeTriggered || millis() < navBlockUntilMs) {
    return false;
  }

  if (currentScreen == SCREEN_DIGITAPE && leftSwipe) {
    settingsRequested = true;
    navBlockUntilMs = millis() + 160;
    touchSuppressUntilMs = millis() + 300;
  } else if (currentScreen != SCREEN_DIGITAPE && !leftSwipe) {
    bool onBrightnessSlider = currentScreen == SCREEN_BRIGHTNESS &&
                              swipeStartPoint.y >= 166 &&
                              swipeStartPoint.y <= 286;
    if (swipeStartPoint.x > 124 || onBrightnessSlider) {
      return false;
    }
    backRequested = true;
    navBlockUntilMs = millis() + 80;
    touchSuppressUntilMs = millis() + 120;
  } else {
    return false;
  }

  swipeTriggered = true;
  touchHoldUntilMs = 0;
  return true;
}

static void handleSwipeSample(const lv_point_t &point)
{
  if (!touchTracking) {
    touchTracking = true;
    swipeTriggered = false;
    swipeStartPoint = point;
    return;
  }

  if (swipeTriggered || millis() < navBlockUntilMs) {
    return;
  }

  int16_t dx = point.x - swipeStartPoint.x;
  int16_t dy = point.y - swipeStartPoint.y;
  int16_t minDx = (currentScreen == SCREEN_DIGITAPE) ? 38 : 40;
  if (abs(dx) < minDx || abs(dy) > 120) {
    return;
  }

  triggerNavigationSwipe(dx < 0);
}

static void finishSwipeSample()
{
  if (touchTracking && !swipeTriggered) {
    int16_t dx = lastTouchPoint.x - swipeStartPoint.x;
    int16_t dy = lastTouchPoint.y - swipeStartPoint.y;
    int16_t minDx = (currentScreen == SCREEN_DIGITAPE) ? 38 : 40;
    if (abs(dx) >= minDx && abs(dy) <= 120) {
      triggerNavigationSwipe(dx < 0);
    }
  }
  touchTracking = false;
  swipeTriggered = false;
}

static void touchRead(lv_indev_drv_t *, lv_indev_data_t *data)
{
  if (CST816->IIC_Interrupt_Flag) {
    CST816->IIC_Interrupt_Flag = false;
    String gesture = CST816->IIC_Read_Device_State(CST816->Arduino_IIC_Touch::Status_Information::TOUCH_GESTURE_ID);
    int32_t touchX = CST816->IIC_Read_Device_Value(CST816->Arduino_IIC_Touch::Value_Information::TOUCH_COORDINATE_X);
    int32_t touchY = CST816->IIC_Read_Device_Value(CST816->Arduino_IIC_Touch::Value_Information::TOUCH_COORDINATE_Y);
    if (normalizeTouchPoint(touchX, touchY, &lastTouchPoint)) {
      handleSwipeSample(lastTouchPoint);
      if (gesture == "Swipe Left") {
        triggerNavigationSwipe(true);
      } else if (gesture == "Swipe Right" && lastTouchPoint.x <= 124) {
        triggerNavigationSwipe(false);
      }
      if (swipeTriggered) {
        data->point = lastTouchPoint;
        data->state = LV_INDEV_STATE_REL;
        return;
      }
      touchHoldUntilMs = millis() + 90;
      touchTrackingUntilMs = millis() + 260;
      data->point = lastTouchPoint;
      data->state = LV_INDEV_STATE_PR;
      return;
    }
  }

  if (millis() < touchHoldUntilMs) {
    data->point = lastTouchPoint;
    data->state = LV_INDEV_STATE_PR;
    return;
  }

  data->point = lastTouchPoint;
  data->state = LV_INDEV_STATE_REL;
  if (millis() >= touchTrackingUntilMs) {
    finishSwipeSample();
  }
}

static void setScreenBg(lv_obj_t *obj)
{
  lv_obj_set_style_bg_color(obj, lv_color_black(), 0);
  lv_obj_set_style_text_color(obj, lv_color_white(), 0);
  lv_obj_set_style_border_width(obj, 0, 0);
  lv_obj_set_style_pad_all(obj, 0, 0);
}

static lv_obj_t *makeLabel(lv_obj_t *parent, const char *text, int y, const lv_font_t *font, lv_color_t color)
{
  lv_obj_t *label = lv_label_create(parent);
  lv_label_set_text(label, text);
  lv_obj_set_style_text_font(label, font, 0);
  lv_obj_set_style_text_color(label, color, 0);
  lv_obj_align(label, LV_ALIGN_TOP_MID, 0, y);
  return label;
}

static lv_obj_t *makeLogo(lv_obj_t *parent, const lv_img_dsc_t *src, int y)
{
  lv_obj_t *img = lv_img_create(parent);
  lv_img_set_src(img, src);
  lv_obj_align(img, LV_ALIGN_TOP_MID, 0, y);
  return img;
}

static lv_obj_t *makeCornerLabel(lv_obj_t *parent, const char *text, int x, int y, const lv_font_t *font, lv_color_t color)
{
  lv_obj_t *label = lv_label_create(parent);
  lv_label_set_text(label, text);
  lv_obj_set_style_text_font(label, font, 0);
  lv_obj_set_style_text_color(label, color, 0);
  lv_obj_align(label, LV_ALIGN_TOP_RIGHT, x, y);
  return label;
}

static lv_obj_t *makeBatteryPill(lv_obj_t *parent)
{
  lv_obj_t *pill = lv_obj_create(parent);
  lv_obj_set_size(pill, 74, 34);
  lv_obj_align(pill, LV_ALIGN_TOP_RIGHT, -20, 33);
  lv_obj_set_style_radius(pill, 12, 0);
  lv_obj_set_style_bg_color(pill, lv_color_hex(0x111111), 0);
  lv_obj_set_style_border_width(pill, 1, 0);
  lv_obj_set_style_border_color(pill, lv_color_hex(0x303030), 0);
  lv_obj_set_style_pad_all(pill, 0, 0);

  lv_obj_t *label = lv_label_create(pill);
  lv_label_set_text(label, "--%");
  lv_obj_set_style_text_font(label, &lv_font_montserrat_22, 0);
  lv_obj_set_style_text_color(label, lv_color_hex(0xbdbdbd), 0);
  lv_obj_center(label);
  return label;
}

static lv_obj_t *makeButton(lv_obj_t *parent, const char *title, int x, int y, int w, int h, lv_event_cb_t cb)
{
  lv_obj_t *btn = lv_btn_create(parent);
  lv_obj_set_size(btn, w, h);
  lv_obj_align(btn, LV_ALIGN_TOP_LEFT, x, y);
  lv_obj_set_style_radius(btn, 18, 0);
  lv_obj_set_style_bg_color(btn, lv_color_hex(0x151515), 0);
  lv_obj_set_style_bg_color(btn, lv_color_hex(0x0c5f2a), LV_STATE_PRESSED);
  lv_obj_set_style_border_width(btn, 2, 0);
  lv_obj_set_style_border_color(btn, lv_color_hex(0x303030), 0);
  lv_obj_add_event_cb(btn, cb, LV_EVENT_CLICKED, NULL);

  lv_obj_t *titleLabel = lv_label_create(btn);
  lv_label_set_text(titleLabel, title);
  lv_obj_set_style_text_font(titleLabel, &lv_font_montserrat_28, 0);
  lv_obj_set_style_text_color(titleLabel, lv_color_white(), 0);
  lv_obj_center(titleLabel);
  return btn;
}

static void clearRoot()
{
  if (root) {
    lv_obj_del(root);
  }
  timeLabel = nullptr;
  dateLabel = nullptr;
  distanceLabel = nullptr;
  routeLabel = nullptr;
  routeButton = nullptr;
  routeButtonLabel = nullptr;
  statusLabel = nullptr;
  diagLabel = nullptr;
  brightnessSlider = nullptr;
  wifiStatusLabel = nullptr;
  batteryLabel = nullptr;
  root = lv_obj_create(lv_scr_act());
  lv_obj_set_size(root, screenWidth, screenHeight);
  lv_obj_align(root, LV_ALIGN_TOP_LEFT, 0, 0);
  setScreenBg(root);
}

static void showHome();
static void showTime();
static void showDigiTape();
static void showSettings();
static void showWifiSetup();
static void showBrightness();
static void showDiagnostics();
static void showBootLogo();
static void showFirmwareFlashPage(bool viaWifi = false);
static void updateDiagnostics();

static bool navAllowed()
{
  if (millis() < touchSuppressUntilMs) {
    return false;
  }
  if (millis() < navBlockUntilMs) {
    return false;
  }
  navBlockUntilMs = millis() + 180;
  return true;
}

static void navHome(lv_event_t *) { if (navAllowed()) showHome(); }
static void navTime(lv_event_t *) { if (navAllowed()) showTime(); }
static void navDigiTape(lv_event_t *) { if (navAllowed()) showDigiTape(); }
static void navSettings(lv_event_t *) { if (navAllowed()) showSettings(); }
static void navBrightness(lv_event_t *) { if (navAllowed()) showBrightness(); }
static void navDiagnostics(lv_event_t *) { if (navAllowed()) showDiagnostics(); }

static void pumpLvglFor(uint32_t durationMs)
{
  uint32_t start = millis();
  while (millis() - start < durationMs) {
    lv_timer_handler();
    delay(5);
  }
}

static void makeBackButton(lv_obj_t *parent)
{
  lv_obj_t *btn = lv_btn_create(parent);
  lv_obj_set_size(btn, 112, 76);
  lv_obj_align(btn, LV_ALIGN_TOP_LEFT, 10, 10);
  lv_obj_set_style_radius(btn, 22, 0);
  lv_obj_set_style_bg_color(btn, lv_color_hex(0x202020), 0);
  lv_obj_set_style_bg_color(btn, lv_color_hex(0x0c5f2a), LV_STATE_PRESSED);
  lv_obj_add_event_cb(btn, navHome, LV_EVENT_PRESSED, NULL);

  lv_obj_t *label = lv_label_create(btn);
  lv_label_set_text(label, "<");
  lv_obj_set_style_text_font(label, &lv_font_montserrat_28, 0);
  lv_obj_center(label);
}

static String formatDistanceFromPacket(const uint8_t *data, size_t length)
{
  if (length >= 2) {
    uint16_t cm = data[0] | (data[1] << 8);
    int totalInches = int(roundf((cm / 2.54f)));
    char text[18];
    snprintf(text, sizeof(text), "%d' %d\"", totalInches / 12, totalInches % 12);
    return String(text);
  }

  String asText;
  for (size_t i = 0; i < length; i++) {
    if (isPrintable(data[i])) {
      asText += char(data[i]);
    }
  }
  return asText.length() ? asText : DISTANCE_PLACEHOLDER;
}

static void distanceNotifyCallback(BLERemoteCharacteristic *, uint8_t *data, size_t length, bool)
{
  distanceText = formatDistanceFromPacket(data, length);
  statusText = "Live";
  lastPacketMs = millis();
  digitapeDirty = true;
}

static void statusNotifyCallback(BLERemoteCharacteristic *, uint8_t *data, size_t length, bool)
{
  statusText = "";
  for (size_t i = 0; i < length; i++) {
    if (isPrintable(data[i])) {
      statusText += char(data[i]);
    }
  }
  if (!statusText.length()) {
    statusText = "Status";
  }
  digitapeDirty = true;
}

class ScanCallbacks : public BLEAdvertisedDeviceCallbacks {
  void onResult(BLEAdvertisedDevice advertisedDevice) override
  {
    String name = advertisedDevice.getName().c_str();
    if (name == wantedName()) {
      BLEDevice::getScan()->stop();
      delete targetDevice;
      targetDevice = new BLEAdvertisedDevice(advertisedDevice);
    }
  }
};

static void startScan()
{
  if (!bleReady) {
    statusText = "BLE starting";
    digitapeDirty = true;
    return;
  }

  scanCount++;
  connected = false;
  distanceChar = nullptr;
  settingsChar = nullptr;
  statusChar = nullptr;
  delete targetDevice;
  targetDevice = nullptr;
  statusText = "Scanning";
  digitapeDirty = true;

  USBSerial.printf("[ble] scan #%lu for %s\n", (unsigned long)scanCount, wantedName());
  BLEScan *scan = BLEDevice::getScan();
  scan->setAdvertisedDeviceCallbacks(new ScanCallbacks(), true);
  scan->setInterval(120);
  scan->setWindow(80);
  scan->setActiveScan(true);
  scan->start(1, false);
  lastScanMs = millis();
}

static bool connectToTarget()
{
  if (!targetDevice) {
    return false;
  }

  statusText = "Connecting";
  digitapeDirty = true;

  delete client;
  client = BLEDevice::createClient();
  if (!client->connect(targetDevice)) {
    statusText = "Connect failed";
    digitapeDirty = true;
    return false;
  }

  BLERemoteService *service = client->getService(serviceUUID);
  if (!service) {
    statusText = "No service";
    client->disconnect();
    digitapeDirty = true;
    return false;
  }

  distanceChar = service->getCharacteristic(distanceUUID);
  settingsChar = service->getCharacteristic(settingsUUID);
  statusChar = service->getCharacteristic(statusUUID);

  if (!distanceChar) {
    statusText = "No distance";
    client->disconnect();
    digitapeDirty = true;
    return false;
  }

  if (distanceChar->canNotify()) {
    distanceChar->registerForNotify(distanceNotifyCallback);
  }
  if (statusChar && statusChar->canNotify()) {
    statusChar->registerForNotify(statusNotifyCallback);
  }

  connected = true;
  statusText = "Connected";
  lastPacketMs = millis();
  digitapeDirty = true;
  return true;
}

static void switchRouteEvent(lv_event_t *)
{
  preferredRoute = preferredRoute == "TX" ? "RX" : "TX";
  distanceText = DISTANCE_PLACEHOLDER;
  statusText = "Switching";
  digitapeDirty = true;

  if (settingsChar && settingsChar->canWrite()) {
    String command = "route=" + preferredRoute;
    settingsChar->writeValue((uint8_t *)command.c_str(), command.length(), true);
  }
  if (client && client->isConnected()) {
    client->disconnect();
  }
  startScan();
}

static void updateDigiTapeLabels()
{
  bool live = connected && (millis() - lastPacketMs < 2500);
  if (distanceLabel) {
    lv_label_set_text(distanceLabel, distanceText.c_str());
  }
  if (routeButton) {
    lv_obj_set_style_bg_color(routeButton, live ? lv_color_hex(0x0c5f2a) : lv_color_hex(0xa91515), 0);
    lv_obj_set_style_bg_color(routeButton, live ? lv_color_hex(0x178f42) : lv_color_hex(0xd62626), LV_STATE_PRESSED);
  }
  if (routeButtonLabel) {
    lv_label_set_text(routeButtonLabel, preferredRoute.c_str());
  }
  if (statusLabel) {
    lv_label_set_text(statusLabel, live ? "LIVE" : statusText.c_str());
    lv_obj_set_style_text_color(statusLabel, live ? lv_color_hex(0x22e36f) : lv_color_hex(0xbdbdbd), 0);
  }
  digitapeDirty = false;
}

static void updateWifiStatusLabel()
{
  if (wifiStatusLabel) {
    lv_label_set_text(wifiStatusLabel, wifiStatus.c_str());
  }
}

static void setBrightnessLevel(uint8_t index)
{
  brightnessLevelIndex = index % 3;
  brightness = BRIGHTNESS_LEVEL_VALUES[brightnessLevelIndex];
  gfx->setBrightness(brightness);
  if (brightnessSlider) {
    lv_slider_set_value(brightnessSlider, brightness, LV_ANIM_OFF);
  }
}

static void syncBrightnessLevelFromValue()
{
  uint8_t closestIndex = 0;
  uint16_t closestDistance = 255;
  for (uint8_t i = 0; i < 3; i++) {
    uint16_t distance = abs((int)brightness - (int)BRIGHTNESS_LEVEL_VALUES[i]);
    if (distance < closestDistance) {
      closestDistance = distance;
      closestIndex = i;
    }
  }
  brightnessLevelIndex = closestIndex;
}

static void initBatteryMonitor()
{
  pmuReady = power.begin(Wire, AXP2101_SLAVE_ADDRESS, IIC_SDA, IIC_SCL);
  if (!pmuReady) {
    USBSerial.println("[pmu] AXP2101 not ready");
    return;
  }

  power.enableBattDetection();
  power.enableBattVoltageMeasure();
  power.enableVbusVoltageMeasure();
  power.enableSystemVoltageMeasure();
  power.setPowerKeyPressOffTime(XPOWERS_POWEROFF_4S);
  power.disableIRQ(XPOWERS_AXP2101_ALL_IRQ);
  power.clearIrqStatus();
  power.enableIRQ(XPOWERS_AXP2101_PKEY_NEGATIVE_IRQ |
                  XPOWERS_AXP2101_PKEY_POSITIVE_IRQ |
                  XPOWERS_AXP2101_PKEY_LONG_IRQ |
                  XPOWERS_AXP2101_PKEY_SHORT_IRQ);
  USBSerial.println("[pmu] AXP2101 battery monitor ready");
}

static void updateBatteryLabel()
{
  if (!batteryLabel) {
    return;
  }

  char text[12] = "--%";
  lv_color_t color = lv_color_hex(0xbdbdbd);

  if (pmuReady && (power.isVbusIn() || power.isVbusGood() || power.getVbusVoltage() > 4200)) {
    snprintf(text, sizeof(text), "USB");
    color = lv_color_hex(0x7fb7ff);
  } else if (pmuReady && power.isBatteryConnect()) {
    int percent = constrain((int)power.getBatteryPercent(), 0, 100);
    snprintf(text, sizeof(text), "%d%%", percent);
    if (percent <= 20) {
      color = lv_color_hex(0xff5757);
    } else if (percent <= 45) {
      color = lv_color_hex(0xffd45c);
    } else {
      color = lv_color_hex(0x22e36f);
    }
  }

  lv_label_set_text(batteryLabel, text);
  lv_obj_set_style_text_color(batteryLabel, color, 0);
}

static void serviceBattery()
{
  static unsigned long lastBatteryUpdate = 0;
  if (millis() - lastBatteryUpdate < 5000) {
    return;
  }
  lastBatteryUpdate = millis();
  updateBatteryLabel();
}

static void startTimeSync()
{
  if (WiFi.status() != WL_CONNECTED || timeSyncStarted || timeSynced) {
    return;
  }

  timeSyncStarted = true;
  timeSyncStartedMs = millis();
  lastTimeSyncAttemptMs = millis();
  wifiStatus = "Setting time";
  updateWifiStatusLabel();
  configTzTime(TIME_ZONE, "pool.ntp.org", "time.nist.gov", "time.google.com");
  USBSerial.println("[time] NTP sync started");
}

static void serviceTimeSync()
{
  if (WiFi.status() != WL_CONNECTED) {
    timeSyncStarted = false;
    return;
  }

  if (!timeSynced && !timeSyncStarted && millis() - lastTimeSyncAttemptMs > 30000) {
    startTimeSync();
  }

  if (!timeSyncStarted) {
    return;
  }

  struct tm timeInfo;
  if (getLocalTime(&timeInfo, 10) && timeInfo.tm_year + 1900 >= 2024) {
    systemTimeReady = true;
    if (rtcReady) {
      rtc.setDateTime(timeInfo);
    }
    timeSynced = true;
    timeSyncStarted = false;
    wifiStatus = "Time set";
    updateWifiStatusLabel();
    updateTimeLabels();
    USBSerial.println("[time] RTC set from NTP");
  } else if (millis() - timeSyncStartedMs > 15000) {
    timeSyncStarted = false;
    wifiStatus = "Time retry soon";
    updateWifiStatusLabel();
    USBSerial.println("[time] NTP sync timeout");
  }
}

static String wifiPage()
{
  String page;
  page += "<!doctype html><html><head><meta name='viewport' content='width=device-width,initial-scale=1'>";
  page += "<style>body{font-family:-apple-system,BlinkMacSystemFont,sans-serif;background:#111;color:#fff;padding:24px}";
  page += "input,button{font-size:20px;width:100%;box-sizing:border-box;margin:10px 0;padding:12px;border-radius:10px;border:0}";
  page += "button{background:#0c5f2a;color:#fff}</style></head><body>";
  page += "<h1>DigiTape WiFi</h1><form method='POST' action='/save'>";
  page += "<input name='ssid' placeholder='WiFi name' value='" + wifiSsid + "'>";
  page += "<input name='pass' placeholder='Password' type='password'>";
  page += "<button type='submit'>Save and connect</button></form>";
  page += "<p>After saving, reconnect your phone/computer to normal WiFi.</p>";
  page += "</body></html>";
  return page;
}

static void startWifiConnect(const String &ssid, const String &password)
{
  if (!ssid.length()) {
    wifiStatus = "WiFi not set";
    updateWifiStatusLabel();
    return;
  }

  wifiSsid = ssid;
  wifiStatus = "Joining " + ssid;
  updateWifiStatusLabel();
  WiFi.mode(WIFI_STA);
  WiFi.begin(ssid.c_str(), password.c_str());
  wifiConnectStarted = true;
  timeSyncStarted = false;
  timeSynced = false;
  wifiConnectStartedMs = millis();
}

static void handleWifiRoot()
{
  wifiServer.send(200, "text/html", wifiPage());
}

static void handleWifiSave()
{
  String ssid = wifiServer.arg("ssid");
  String pass = wifiServer.arg("pass");
  ssid.trim();
  wifiPrefs.begin("wifi", false);
  wifiPrefs.putString("ssid", ssid);
  wifiPrefs.putString("pass", pass);
  wifiPrefs.end();
  wifiServer.send(200, "text/html", "<html><body><h1>Saved</h1><p>DigiTape is connecting to WiFi.</p></body></html>");
  startWifiConnect(ssid, pass);
}

static void startWifiSetup()
{
  if (wifiSetupActive) {
    wifiStatus = "Setup: 192.168.4.1";
    updateWifiStatusLabel();
    return;
  }

  wifiSetupActive = true;
  wifiStatus = "Starting setup";
  updateWifiStatusLabel();

  if (client && client->isConnected()) {
    client->disconnect();
  }
  connected = false;
  BLEDevice::getScan()->stop();

  WiFi.mode(WIFI_AP_STA);
  WiFi.softAP("DigiTape-Setup");
  wifiServer.on("/", HTTP_GET, handleWifiRoot);
  wifiServer.on("/save", HTTP_POST, handleWifiSave);
  wifiServer.begin();
  wifiStatus = "Setup: 192.168.4.1";
  updateWifiStatusLabel();
}

static void startSavedWifi()
{
  wifiPrefs.begin("wifi", true);
  String ssid = wifiPrefs.getString("ssid", "");
  String pass = wifiPrefs.getString("pass", "");
  wifiPrefs.end();
  if (ssid.length()) {
    startWifiConnect(ssid, pass);
  } else {
    wifiSsid = DEFAULT_WIFI_SSID;
    wifiStatus = "Need " + wifiSsid + " pass";
  }
}

static void wifiSetupEvent(lv_event_t *)
{
  if (millis() < touchSuppressUntilMs) {
    return;
  }
  wifiSetupRequested = true;
  wifiStatus = "Starting setup";
  updateWifiStatusLabel();
  showWifiSetup();
}

static void serviceWifi()
{
  if (wifiSetupRequested) {
    wifiSetupRequested = false;
    startWifiSetup();
  }

  if (wifiSetupActive) {
    wifiServer.handleClient();
  }

  if (wifiConnectStarted) {
    if (WiFi.status() == WL_CONNECTED) {
      wifiConnectStarted = false;
      wifiStatus = "WiFi " + WiFi.localIP().toString();
      updateWifiStatusLabel();
      startTimeSync();
    } else if (millis() - wifiConnectStartedMs > 15000) {
      wifiConnectStarted = false;
      wifiStatus = "WiFi failed";
      updateWifiStatusLabel();
    }
  }

  serviceTimeSync();
}

static void formatClock12(char *buffer, size_t bufferSize, int hour24, int minute)
{
  int hour12 = hour24 % 12;
  if (hour12 == 0) {
    hour12 = 12;
  }
  snprintf(buffer, bufferSize, "%d:%02d", hour12, minute);
}

static void updateTimeLabels()
{
  if (!timeLabel) {
    return;
  }

  char timeText[16] = "--:--";
  char dateText[24] = "RTC not set";
  if (rtcReady) {
    RTC_DateTime dt = rtc.getDateTime();
    if (dt.getYear() >= 2024) {
      formatClock12(timeText, sizeof(timeText), dt.getHour(), dt.getMinute());
      snprintf(dateText, sizeof(dateText), "%04d-%02d-%02d", dt.getYear(), dt.getMonth(), dt.getDay());
    } else {
      unsigned long seconds = millis() / 1000;
      formatClock12(timeText, sizeof(timeText), (seconds / 3600) % 24, (seconds / 60) % 60);
      snprintf(dateText, sizeof(dateText), "Syncing");
    }
  } else if (systemTimeReady) {
    struct tm timeInfo;
    if (getLocalTime(&timeInfo, 10)) {
      formatClock12(timeText, sizeof(timeText), timeInfo.tm_hour, timeInfo.tm_min);
      snprintf(dateText, sizeof(dateText), "%04d-%02d-%02d", timeInfo.tm_year + 1900, timeInfo.tm_mon + 1, timeInfo.tm_mday);
    }
  } else {
    unsigned long seconds = millis() / 1000;
    formatClock12(timeText, sizeof(timeText), (seconds / 3600) % 24, (seconds / 60) % 60);
    snprintf(dateText, sizeof(dateText), "Uptime");
  }

  lv_label_set_text(timeLabel, timeText);
  if (dateLabel) {
    lv_label_set_text(dateLabel, dateText);
  }
}

static void showHome()
{
  currentScreen = SCREEN_HOME;
  clearRoot();
  timeLabel = makeLabel(root, "--:--", 34, &lv_font_montserrat_28, lv_color_white());
  batteryLabel = makeBatteryPill(root);
  makeButton(root, "DigiTape", 34, 126, 300, 112, navDigiTape);
  makeButton(root, "Settings", 34, 278, 300, 112, navSettings);
  updateTimeLabels();
  updateBatteryLabel();
}

static void showTime()
{
  currentScreen = SCREEN_TIME;
  clearRoot();
  makeLabel(root, "TIME", 34, &lv_font_montserrat_22, lv_color_hex(0xb0b0b0));
  timeLabel = makeLabel(root, "--:--", 142, &lv_font_montserrat_48, lv_color_white());
  dateLabel = makeLabel(root, "", 232, &lv_font_montserrat_22, lv_color_hex(0xb0b0b0));
  updateTimeLabels();
}

static void showDigiTape()
{
  currentScreen = SCREEN_DIGITAPE;
  clearRoot();
  distanceLabel = makeLabel(root, DISTANCE_PLACEHOLDER, 96, &lv_font_montserrat_48, lv_color_white());
  lv_obj_set_width(distanceLabel, screenWidth);
  lv_obj_set_style_text_align(distanceLabel, LV_TEXT_ALIGN_CENTER, 0);
  statusLabel = makeLabel(root, "Scanning", 222, &lv_font_montserrat_22, lv_color_hex(0xbdbdbd));

  routeButton = lv_btn_create(root);
  lv_obj_set_size(routeButton, 190, 72);
  lv_obj_align(routeButton, LV_ALIGN_TOP_MID, 0, 316);
  lv_obj_set_style_radius(routeButton, 24, 0);
  lv_obj_set_style_bg_color(routeButton, lv_color_hex(0xa91515), 0);
  lv_obj_set_style_bg_color(routeButton, lv_color_hex(0xd62626), LV_STATE_PRESSED);
  lv_obj_add_event_cb(routeButton, switchRouteEvent, LV_EVENT_CLICKED, NULL);
  routeButtonLabel = lv_label_create(routeButton);
  lv_label_set_text(routeButtonLabel, preferredRoute.c_str());
  lv_obj_set_style_text_font(routeButtonLabel, &lv_font_montserrat_34, 0);
  lv_obj_center(routeButtonLabel);

  updateDigiTapeLabels();
  if (!connected && millis() - lastScanMs > 1500) {
    startScan();
  }
}

static void brightnessChanged(lv_event_t *event)
{
  lv_obj_t *slider = lv_event_get_target(event);
  brightness = lv_slider_get_value(slider);
  syncBrightnessLevelFromValue();
  gfx->setBrightness(brightness);
}

static void showSettings()
{
  currentScreen = SCREEN_SETTINGS;
  clearRoot();
  makeLabel(root, "SETTINGS", 34, &lv_font_montserrat_22, lv_color_hex(0xb0b0b0));
  makeButton(root, "Brightness", 34, 100, 300, 74, navBrightness);
  makeButton(root, "WiFi", 34, 200, 300, 74, wifiSetupEvent);
  makeButton(root, "Diagnostics", 34, 300, 300, 74, navDiagnostics);
  wifiStatusLabel = makeLabel(root, wifiStatus.c_str(), 394, &lv_font_montserrat_18, lv_color_hex(0xbdbdbd));
}

static void showWifiSetup()
{
  currentScreen = SCREEN_WIFI_SETUP;
  clearRoot();
  makeLabel(root, LV_SYMBOL_WIFI, 48, &lv_font_montserrat_48, lv_color_hex(0x7fb7ff));
  makeLabel(root, "WiFi Setup", 132, &lv_font_montserrat_28, lv_color_white());
  makeLabel(root, "DigiTape-Setup", 206, &lv_font_montserrat_28, lv_color_hex(0xbdbdbd));
  makeLabel(root, "192.168.4.1", 270, &lv_font_montserrat_28, lv_color_hex(0x22e36f));
  wifiStatusLabel = makeLabel(root, wifiStatus.c_str(), 360, &lv_font_montserrat_18, lv_color_hex(0xbdbdbd));
}

static void showBrightness()
{
  currentScreen = SCREEN_BRIGHTNESS;
  clearRoot();
  makeLabel(root, "BRIGHTNESS", 34, &lv_font_montserrat_22, lv_color_hex(0xb0b0b0));
  makeLabel(root, "Display", 128, &lv_font_montserrat_28, lv_color_white());

  brightnessSlider = lv_slider_create(root);
  lv_obj_set_size(brightnessSlider, 300, 44);
  lv_obj_align(brightnessSlider, LV_ALIGN_TOP_MID, 0, 202);
  lv_obj_set_style_radius(brightnessSlider, 18, 0);
  lv_obj_set_style_bg_color(brightnessSlider, lv_color_hex(0x242424), 0);
  lv_obj_set_style_border_width(brightnessSlider, 3, 0);
  lv_obj_set_style_border_color(brightnessSlider, lv_color_hex(0xd8d8d8), 0);
  lv_obj_set_style_border_opa(brightnessSlider, LV_OPA_80, 0);
  lv_obj_set_style_bg_color(brightnessSlider, lv_color_hex(0x22e36f), LV_PART_INDICATOR);
  lv_obj_set_style_bg_color(brightnessSlider, lv_color_white(), LV_PART_KNOB);
  lv_obj_set_style_pad_all(brightnessSlider, 10, LV_PART_KNOB);
  lv_slider_set_range(brightnessSlider, 30, 255);
  lv_slider_set_value(brightnessSlider, brightness, LV_ANIM_OFF);
  lv_obj_add_event_cb(brightnessSlider, brightnessChanged, LV_EVENT_VALUE_CHANGED, NULL);
}

static void showDiagnostics()
{
  currentScreen = SCREEN_DIAGNOSTICS;
  clearRoot();
  makeLabel(root, "DIAGNOSTICS", 30, &lv_font_montserrat_28, lv_color_hex(0xb0b0b0));
  diagLabel = lv_label_create(root);
  lv_label_set_text(diagLabel, "");
  lv_obj_set_width(diagLabel, screenWidth - 42);
  lv_label_set_long_mode(diagLabel, LV_LABEL_LONG_WRAP);
  lv_obj_set_style_text_font(diagLabel, &lv_font_montserrat_22, 0);
  lv_obj_set_style_text_color(diagLabel, lv_color_white(), 0);
  lv_obj_set_style_text_align(diagLabel, LV_TEXT_ALIGN_LEFT, 0);
  lv_obj_set_style_text_line_space(diagLabel, 7, 0);
  lv_obj_align(diagLabel, LV_ALIGN_TOP_LEFT, 22, 92);
}

static void showBootLogo()
{
  clearRoot();
  makeLogo(root, &digitape_logo_boot, 118);
  makeLabel(root, "DigiTape", 250, &lv_font_montserrat_34, lv_color_white());
  makeLabel(root, "Mini RX", 306, &lv_font_montserrat_18, lv_color_hex(0xbdbdbd));
  pumpLvglFor(900);
}

static void showFirmwareFlashPage(bool viaWifi)
{
  clearRoot();
  makeLogo(root, &digitape_logo_flash, 28);
  makeLabel(root, "FIRMWARE", 100, &lv_font_montserrat_22, lv_color_hex(0xb0b0b0));
  makeLabel(root, viaWifi ? LV_SYMBOL_WIFI : LV_SYMBOL_USB, 150, &lv_font_montserrat_48, lv_color_hex(0x7fb7ff));
  makeLabel(root, "Flashing", 218, &lv_font_montserrat_34, lv_color_white());
  makeLabel(root, viaWifi ? "WiFi update" : "USB update", 286, &lv_font_montserrat_22, lv_color_hex(0xbdbdbd));
  pumpLvglFor(250);
}

static void showPowerOffPage()
{
  clearRoot();
  makeLabel(root, "POWER", 104, &lv_font_montserrat_22, lv_color_hex(0xb0b0b0));
  makeLabel(root, "Powering off", 174, &lv_font_montserrat_34, lv_color_white());
  makeLabel(root, "Hold complete", 254, &lv_font_montserrat_22, lv_color_hex(0xbdbdbd));
  pumpLvglFor(300);
}

static void updateDiagnostics()
{
  if (!diagLabel) {
    return;
  }
  String text;
  text += "FW: ";
  text += FIRMWARE_NAME;
  text += " ";
  text += FIRMWARE_VERSION;
  text += "\n";
  text += "Route: " + preferredRoute + "\n";
  text += "BLE: ";
  text += connected ? "Connected\n" : "Scanning\n";
  text += "Status: " + statusText + "\n";
  text += "Scans: " + String(scanCount) + "\n";
  text += "RTC: ";
  text += rtcReady ? "Ready\n" : "Fallback\n";
  text += "Btn: " + String(expander.digitalRead(BOTTOM_BUTTON_EXPANDER_PIN) ? "1" : "0");
  text += " IRQ: " + String(expander.digitalRead(PMU_IRQ_EXPANDER_PIN) ? "1\n" : "0\n");
  text += "WiFi: " + wifiStatus;
  lv_label_set_text(diagLabel, text.c_str());
}

static void serviceSerialCommands()
{
  static String command;
  while (USBSerial.available()) {
    char c = USBSerial.read();
    if (c == '\n' || c == '\r') {
      command.trim();
      if (command == "FLASHING") {
        showFirmwareFlashPage(false);
      } else if (command == "FLASHING_WIFI") {
        showFirmwareFlashPage(true);
      }
      command = "";
    } else if (command.length() < 48) {
      command += c;
    }
  }
}

static void requestPowerOff()
{
  if (powerOffRequested) {
    return;
  }
  powerOffRequested = true;
  USBSerial.println("[power] top button held; shutting down");
  showPowerOffPage();
  if (pmuReady) {
    power.shutdown();
  }
  while (true) {
    delay(1000);
  }
}

static void servicePhysicalButtons()
{
  bool bottomState = expander.digitalRead(BOTTOM_BUTTON_EXPANDER_PIN);
  if (!bottomButtonReady) {
    bottomButtonIdleState = bottomState;
    bottomButtonReady = true;
  }
  bool bottomPressed = bottomState != bottomButtonIdleState;
  if (bottomPressed && !bottomButtonWasPressed && millis() - lastBottomButtonMs > 250) {
    lastBottomButtonMs = millis();
    setBrightnessLevel(brightnessLevelIndex + 1);
    USBSerial.printf("[button] brightness=%u state=%u idle=%u\n", brightness, bottomState, bottomButtonIdleState);
  }
  bottomButtonWasPressed = bottomPressed;

  if (!pmuReady) {
    return;
  }

  if (powerKeyHeld && millis() - powerKeyPressStartedMs >= 5000) {
    requestPowerOff();
    return;
  }

  if (expander.digitalRead(PMU_IRQ_EXPANDER_PIN) != HIGH) {
    return;
  }

  power.getIrqStatus();
  if (power.isPekeyNegativeIrq() || power.isPekeyPositiveIrq()) {
    powerKeyHeld = true;
    powerKeyPressStartedMs = millis();
    USBSerial.println("[power] top button press");
  }
  if (power.isPekeyShortPressIrq()) {
    powerKeyHeld = false;
  }
  if (power.isPekeyLongPressIrq()) {
    if (!powerKeyHeld) {
      powerKeyHeld = true;
      powerKeyPressStartedMs = millis();
    }
  }
  power.clearIrqStatus();
}

static void initPower()
{
  Wire.begin(IIC_SDA, IIC_SCL);
  if (expander.begin(0x20)) {
    for (uint8_t pin = 0; pin < 3; pin++) {
      expander.pinMode(pin, OUTPUT);
      expander.digitalWrite(pin, LOW);
    }
    expander.pinMode(6, OUTPUT);
    expander.digitalWrite(6, LOW);
    expander.pinMode(BOTTOM_BUTTON_EXPANDER_PIN, INPUT);
    expander.pinMode(PMU_IRQ_EXPANDER_PIN, INPUT);
    delay(30);
    for (uint8_t pin = 0; pin < 3; pin++) {
      expander.digitalWrite(pin, HIGH);
    }
    expander.digitalWrite(6, HIGH);
    delay(80);
  } else {
    USBSerial.println("[power] XCA9554 not found");
  }
}

static void initLvgl()
{
  gfx->begin();
  gfx->setBrightness(brightness);
  screenWidth = gfx->width();
  screenHeight = gfx->height();

  lv_init();
  lv_color_t *buf1 = (lv_color_t *)heap_caps_malloc(screenWidth * screenHeight / 6 * sizeof(lv_color_t), MALLOC_CAP_DMA);
  lv_color_t *buf2 = (lv_color_t *)heap_caps_malloc(screenWidth * screenHeight / 6 * sizeof(lv_color_t), MALLOC_CAP_DMA);
  lv_disp_draw_buf_init(&draw_buf, buf1, buf2, screenWidth * screenHeight / 6);

  static lv_disp_drv_t dispDrv;
  lv_disp_drv_init(&dispDrv);
  dispDrv.hor_res = screenWidth;
  dispDrv.ver_res = screenHeight;
  dispDrv.flush_cb = displayFlush;
  dispDrv.draw_buf = &draw_buf;
  dispDrv.sw_rotate = 1;
  lv_disp_drv_register(&dispDrv);

  static lv_indev_drv_t inputDrv;
  lv_indev_drv_init(&inputDrv);
  inputDrv.type = LV_INDEV_TYPE_POINTER;
  inputDrv.read_cb = touchRead;
  lv_indev_drv_register(&inputDrv);

  const esp_timer_create_args_t tickArgs = {
    .callback = &lvTick,
    .name = "lvgl_tick"
  };
  esp_timer_handle_t tickTimer = NULL;
  esp_timer_create(&tickArgs, &tickTimer);
  esp_timer_start_periodic(tickTimer, EXAMPLE_LVGL_TICK_PERIOD_MS * 1000);
}

void setup()
{
  USBSerial.begin(115200);
  delay(250);
  USBSerial.print("[boot] ");
  USBSerial.print(FIRMWARE_NAME);
  USBSerial.print(" ");
  USBSerial.println(FIRMWARE_VERSION);

  initPower();
  while (!CST816->begin()) {
    USBSerial.println("[touch] CST816 retry");
    delay(500);
  }
  CST816->IIC_Write_Device_State(
    CST816->Arduino_IIC_Touch::Device::TOUCH_DEVICE_INTERRUPT_MODE,
    CST816->Arduino_IIC_Touch::Device_Mode::TOUCH_DEVICE_INTERRUPT_PERIODIC);
  USBSerial.println("[touch] CST816 ready");

  rtcReady = rtc.begin(Wire, IIC_SDA, IIC_SCL);
  if (!rtcReady) {
    USBSerial.println("[rtc] PCF85063 not ready; using uptime clock");
  }
  seedClockFromBuildTime();
  initBatteryMonitor();

  initLvgl();
  BLEDevice::init(FIRMWARE_NAME);
  bleReady = true;
  showBootLogo();
  showDigiTape();

  startSavedWifi();
}

void loop()
{
  serviceSerialCommands();
  servicePhysicalButtons();
  serviceWifi();
  serviceBattery();

  if (settingsRequested) {
    settingsRequested = false;
    showSettings();
  }

  if (backRequested) {
    backRequested = false;
    showDigiTape();
  }

  bool digitapeActive = currentScreen == SCREEN_DIGITAPE;
  if (digitapeActive && !connected) {
    if (targetDevice) {
      connectToTarget();
    } else if (millis() - lastScanMs > 5000) {
      startScan();
    }
  }

  if (connected && client && !client->isConnected()) {
    connected = false;
    distanceText = DISTANCE_PLACEHOLDER;
    statusText = "Disconnected";
    digitapeDirty = true;
  }

  if (currentScreen == SCREEN_HOME || currentScreen == SCREEN_TIME) {
    static unsigned long lastTimeUpdate = 0;
    if (millis() - lastTimeUpdate > 1000) {
      lastTimeUpdate = millis();
      updateTimeLabels();
    }
  }

  if (currentScreen == SCREEN_DIGITAPE && digitapeDirty) {
    updateDigiTapeLabels();
  }
  if (currentScreen == SCREEN_SETTINGS || currentScreen == SCREEN_DIAGNOSTICS) {
    static unsigned long lastDiagUpdate = 0;
    if (millis() - lastDiagUpdate > 1000) {
      lastDiagUpdate = millis();
      updateDiagnostics();
    }
  }

  lv_timer_handler();
  delay(2);
}
